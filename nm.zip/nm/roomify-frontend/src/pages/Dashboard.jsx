import React from 'react'

import { Container, Typography } from '@mui/material';


const Dashboard = () => {
  return (
    <Container>
      <Typography variant="h4">Welcome to Roomify Dashboard</Typography>
    </Container>
  )
}

export default Dashboard
